			//
			//  ANEFileSync.m
			//  ANEFileSync
			//
			//  Created by ANEBridgeCreator on 28/01/2013.
			//  Copyright (c)2013 ANEBridgeCreator. All rights reserved.
			//
			
			#import "FlashRuntimeExtensions.h"
			
			#define DEFINE_ANE_FUNCTION(fn) FREObject (fn)(FREContext context, void* functionData, uint32_t argc, FREObject argv[])
			#define DISPATCH_STATUS_EVENT(extensionContext, code, status) FREDispatchStatusEventAsync((extensionContext), (uint8_t*)code, (uint8_t*)status)
			#define MAP_FUNCTION(fn, data) { (const uint8_t*)(#fn), (data), &(fn) }
			
			#define ASSERT_ARGC_IS(fn_name, required)																	\
			if(argc != (required))																						\
			{																											\
				DISPATCH_INTERNAL_ERROR(context, #fn_name ": Wrong number of arguments. Expected exactly " #required);	\
				return NULL;																							\
			}
			#define ASSERT_ARGC_AT_LEAST(fn_name, required)																\
			if(argc < (required))																						\
			{																											\
				DISPATCH_INTERNAL_ERROR(context, #fn_name ": Wrong number of arguments. Expected at least " #required);	\
				return NULL;																							\
			}
			
			/****************************************************************************************
			 *																						*
			 *	PROPERTIES GETTERS/SETTERS															*
			 *																						*
			 ****************************************************************************************/
			
			 
			
			
			
			/****************************************************************************************
			 *																						*
			 *	METHODS BRIDGED																		*
			 *																						*
			 ****************************************************************************************/
			
			/****************************************************************************************
			 * @method:setDirectoryListingEnabled( enabled:Boolean):void
			 ****************************************************************************************/
			DEFINE_ANE_FUNCTION( setDirectoryListingEnabled )
			{
				
				//  enabled:Boolean = argument[0];
			
				uint32_t enabled_C;
				if( FREGetObjectAsBool(argv[0], &enabled_C) != FRE_OK ) return NULL;
				
			
				return NULL;
			}
			
			
			/****************************************************************************************
			 * @method:setDocumentRoot( directory:String):void
			 ****************************************************************************************/
			DEFINE_ANE_FUNCTION( setDocumentRoot )
			{
				
				//  directory:String = argument[0];
			
				uint32_t directoryLength;
				const uint8_t *directory_CString;
				FREGetObjectAsUTF8(argv[0], &directoryLength, &directory_CString);
				NSString *directory = [NSString stringWithUTF8String:(char*)directory_CString];
				
			
				return NULL;
			}
			
			
			/****************************************************************************************
			 * @method:setListDisplayItemTemplate( template:String):void
			 ****************************************************************************************/
			DEFINE_ANE_FUNCTION( setListDisplayItemTemplate )
			{
				
				//  template:String = argument[0];
			
				uint32_t templateLength;
				const uint8_t *template_CString;
				FREGetObjectAsUTF8(argv[0], &templateLength, &template_CString);
				NSString *template = [NSString stringWithUTF8String:(char*)template_CString];
				
			
				return NULL;
			}
			
			
			/****************************************************************************************
			 * @method:setPort( port:uint):void
			 ****************************************************************************************/
			DEFINE_ANE_FUNCTION( setPort )
			{
				
				//  port:uint = argument[0];
			
				uint32_t port_C;
				if( FREGetObjectAsUInt32(argv[0], &port_C) != FRE_OK ) return NULL;
				
			
				return NULL;
			}
			
			
			/****************************************************************************************
			 * @method:setUploadDir( directory:String):void
			 ****************************************************************************************/
			DEFINE_ANE_FUNCTION( setUploadDir )
			{
				
				//  directory:String = argument[0];
			
				uint32_t directoryLength;
				const uint8_t *directory_CString;
				FREGetObjectAsUTF8(argv[0], &directoryLength, &directory_CString);
				NSString *directory = [NSString stringWithUTF8String:(char*)directory_CString];
				
			
				return NULL;
			}
			
			
			/****************************************************************************************
			 * @method:start( ):void
			 ****************************************************************************************/
			DEFINE_ANE_FUNCTION( start )
			{
				
				return NULL;
			}
			
			
			/****************************************************************************************
			 * @method:stop( ):void
			 ****************************************************************************************/
			DEFINE_ANE_FUNCTION( stop )
			{
				
				return NULL;
			}
			
			
			/****************************************************************************************
			 *																						*
			 *	EXTENSION & CONTEXT																	*
			 *																						*
			 ****************************************************************************************/
			
			void ANEFileSyncContextInitializer( void* extData, const uint8_t* ctxType, FREContext ctx, uint32_t* numFunctionsToSet, const FRENamedFunction** functionsToSet )
			{
				static FRENamedFunction functionMap[] = {
					// METHODS
					MAP_FUNCTION( setDirectoryListingEnabled, NULL ),
					MAP_FUNCTION( setDocumentRoot, NULL ),
					MAP_FUNCTION( setListDisplayItemTemplate, NULL ),
					MAP_FUNCTION( setPort, NULL ),
					MAP_FUNCTION( setUploadDir, NULL ),
					MAP_FUNCTION( start, NULL ),
					MAP_FUNCTION( stop, NULL )
				};
				*numFunctionsToSet = sizeof( functionMap ) / sizeof( FRENamedFunction );
				*functionsToSet = functionMap;
			}
			void ANEFileSyncContextFinalizer( FREContext ctx )
			{
				NSLog(@"Entering ANEFileSyncContextFinalizer()");
				NSLog(@"Exiting ANEFileSyncContextFinalizer()");
				return;
			}
			void ANEFileSyncExtensionInitializer( void** extDataToSet, FREContextInitializer* ctxInitializerToSet, FREContextFinalizer* ctxFinalizerToSet ) 
			{ 
				NSLog(@"Entering ANEFileSyncExtensionInitializer()");
				extDataToSet = NULL;  // This example does not use any extension data.
				*ctxInitializerToSet = &ANEFileSyncContextInitializer;
				*ctxFinalizerToSet = &ANEFileSyncContextFinalizer;
			}
			void ANEFileSyncExtensionFinalizer()
			{
				NSLog(@"Entering ANEFileSyncExtensionFinalizer()");
				return;
			}
			